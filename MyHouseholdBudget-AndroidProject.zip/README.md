# My Household Budget - Android APK project

This project wraps the offline household budget app in a native Android WebView.

## Build an APK with GitHub Actions
1. Upload the contents of this project to your GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK**.
4. Press **Run workflow** (or push to the main branch).
5. When the workflow completes, open it and download the `My-Household-Budget-APK` artifact.
6. Extract the ZIP and install `app-debug.apk` on your Android phone.

The app stores its budget data locally on the device. Use its Backup section to export your information before reinstalling or changing devices.
